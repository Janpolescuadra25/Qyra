// src/background/service-worker.ts
var WINDOW_WIDTH = 950;
var WINDOW_HEIGHT = 750;
if (false) console.log("[Qyra BG] Service worker loaded");
chrome.action.onClicked.addListener(async () => {
  if (false) console.log("[Qyra BG] Extension icon clicked \u2014 opening floating window");
  const storage = await chrome.storage.session.get(["qyraWindowId", "solyraWindowId", "autobooksWindowId", "nestWindowId"]);
  let qyraWindowId = storage.qyraWindowId;
  if (qyraWindowId === void 0 && storage.solyraWindowId !== void 0) {
    qyraWindowId = storage.solyraWindowId;
    await chrome.storage.session.set({ qyraWindowId });
    await chrome.storage.session.remove("solyraWindowId");
  }
  if (qyraWindowId === void 0 && storage.autobooksWindowId !== void 0) {
    qyraWindowId = storage.autobooksWindowId;
    await chrome.storage.session.set({ qyraWindowId });
    await chrome.storage.session.remove("autobooksWindowId");
  }
  if (qyraWindowId === void 0 && storage.nestWindowId !== void 0) {
    qyraWindowId = storage.nestWindowId;
    await chrome.storage.session.set({ qyraWindowId });
    await chrome.storage.session.remove("nestWindowId");
  }
  if (qyraWindowId !== void 0) {
    try {
      await chrome.windows.get(qyraWindowId);
      await chrome.windows.update(qyraWindowId, { focused: true });
      return;
    } catch {
      await chrome.storage.session.remove("qyraWindowId");
      await chrome.storage.session.remove("autobooksWindowId");
      await chrome.storage.session.remove("nestWindowId");
    }
  }
  const popupUrl = chrome.runtime.getURL("popup/index.html");
  try {
    const win = await chrome.windows.create({
      url: popupUrl,
      type: "popup",
      width: WINDOW_WIDTH,
      height: WINDOW_HEIGHT,
      focused: true
    });
    if (win?.id !== void 0) {
      await chrome.storage.session.set({ qyraWindowId: win.id });
    }
  } catch (err) {
    if (false) console.error("[Qyra] Failed to open floating window:", err);
  }
});
chrome.windows.onRemoved.addListener(async (windowId) => {
  const { qyraWindowId } = await chrome.storage.session.get("qyraWindowId");
  if (windowId === qyraWindowId) {
    await chrome.storage.session.remove("qyraWindowId");
  }
});
var qbAuthTabId = null;
var qbAuthCleanupTimer = null;
var cleanupQBAuth = () => {
  qbAuthTabId = null;
  if (qbAuthCleanupTimer !== null) {
    clearTimeout(qbAuthCleanupTimer);
    qbAuthCleanupTimer = null;
  }
};
var handleQBAuthCallbackUrl = (tabId, url) => {
  const callbackUrl = url;
  if (!callbackUrl.includes("/api/quickbooks/callback")) return;
  let success = false;
  let realmId;
  let error;
  try {
    const parsed = new URL(callbackUrl);
    const params = parsed.searchParams;
    const maybeError = params.get("error");
    const code = params.get("code");
    const maybeRealmId = params.get("realmId");
    if (maybeError) {
      error = maybeError;
    } else if (code && maybeRealmId) {
      success = true;
      realmId = maybeRealmId;
    } else {
      error = "Missing QuickBooks callback parameters.";
    }
  } catch (err) {
    error = "Failed to parse QuickBooks callback URL.";
  }
  chrome.tabs.remove(tabId).catch(() => {
  });
  cleanupQBAuth();
  chrome.runtime.sendMessage({
    type: "QB_AUTH_CALLBACK",
    payload: { success, error, realmId }
  });
};
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (qbAuthTabId === null || tabId !== qbAuthTabId) return;
  const url = changeInfo.url ?? tab.url;
  if (!url) return;
  handleQBAuthCallbackUrl(tabId, url);
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "OPEN_QB_AUTH") {
    const { authUrl } = message.payload;
    chrome.tabs.create({ url: authUrl }, (tab) => {
      if (tab?.id !== void 0) {
        qbAuthTabId = tab.id;
        if (qbAuthCleanupTimer !== null) {
          clearTimeout(qbAuthCleanupTimer);
        }
        qbAuthCleanupTimer = setTimeout(() => {
          cleanupQBAuth();
        }, 5 * 60 * 1e3);
      }
      sendResponse({ ok: true });
    });
    return true;
  }
  return false;
});
