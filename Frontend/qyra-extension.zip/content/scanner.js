"use strict";
(() => {
  // src/content/scanner.ts
  function waitForElement(selector, timeoutMs = 5e3) {
    return new Promise((resolve) => {
      const existing = document.querySelector(selector);
      if (existing) return resolve(existing);
      const observer = new MutationObserver(() => {
        const el = document.querySelector(selector);
        if (el) {
          observer.disconnect();
          resolve(el);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, timeoutMs);
    });
  }
  function parseValue(raw) {
    const s = raw.trim();
    if (s === "\u2014" || s === "-" || s === "") return 0;
    if (/^\d{1,2}:\d{2}/.test(s)) {
      return 0;
    }
    if (/^\(.*\)$/.test(s)) {
      const inner = s.replace(/[()$,]/g, "");
      const num2 = parseFloat(inner);
      return isNaN(num2) ? 0 : -num2;
    }
    if (s.endsWith("%")) {
      const num2 = parseFloat(s.replace(/[^0-9.\-]/g, ""));
      return isNaN(num2) ? 0 : num2;
    }
    const cleaned = s.replace(/[$,]/g, "");
    if (cleaned.endsWith("-") && !cleaned.startsWith("-")) {
      const num2 = parseFloat(cleaned.slice(0, -1));
      return isNaN(num2) ? 0 : -num2;
    }
    const num = parseFloat(cleaned);
    return isNaN(num) ? 0 : num;
  }
  function getCellTitle(cell) {
    const raw = cell.querySelector('div[data-testid="formatted-value-text"]')?.getAttribute("title")?.trim() ?? "";
    if (raw.length <= 30) return raw;
    const match = raw.match(/^(.+?[a-z])([A-Z].{10,})$/);
    if (match) {
      const label = match[1];
      const desc = match[2];
      if (/\b(of|that|is|for|the|are|was|will|has|can|may|note|minus)\b/i.test(desc)) {
        return label;
      }
    }
    const repeatMatch = raw.match(/^([A-Z][a-z]+)([A-Z][a-z]+)/);
    if (repeatMatch && repeatMatch[1] === repeatMatch[2]) {
      return repeatMatch[1];
    }
    return raw;
  }
  function getColumnHeaders(headerEl) {
    if (!headerEl) return [];
    const headers = Array.from(
      headerEl.querySelectorAll('div[data-testid="table-header-text"]')
    ).map((el) => el.textContent?.trim() ?? "").filter((h) => h.length > 0);
    if (headers.length > 0) return headers;
    return Array.from(headerEl.querySelectorAll("th")).map((th) => th.textContent?.trim() ?? "").filter((h) => h.length > 0);
  }
  function isTotalRow(row) {
    if (row.closest("tfoot")) return true;
    const firstCell = row.querySelector(":scope > td:first-child");
    if (!firstCell) return false;
    const label = getCellTitle(firstCell);
    return /^total\b/i.test(label);
  }
  function collectTableRows(table) {
    return Array.from(
      table.querySelectorAll(":scope > tbody > tr, :scope > tfoot > tr")
    );
  }
  function extractKeyValueTable(tbody, sectionPrefix) {
    const result = {};
    if (!tbody) return result;
    const table = tbody.closest("table");
    const rows = table ? collectTableRows(table) : Array.from(tbody.querySelectorAll(":scope > tr"));
    rows.forEach((row) => {
      const cells = row.querySelectorAll(":scope > td");
      if (cells.length < 2) return;
      const label = getCellTitle(cells[0]);
      if (label) {
        result[`${sectionPrefix}.${label}`] = parseValue(
          getCellTitle(cells[1])
        );
      }
    });
    return result;
  }
  function extractMultiColumnTable(thead, tbody, sectionPrefix, labelColumnIndex = 0) {
    const result = {};
    if (!tbody) return result;
    const headers = getColumnHeaders(thead);
    const table = tbody.closest("table");
    const rows = table ? collectTableRows(table) : Array.from(tbody.querySelectorAll(":scope > tr"));
    rows.forEach((row) => {
      const cells = row.querySelectorAll(":scope > td");
      if (cells.length < 2) return;
      const total = isTotalRow(row);
      const label = getCellTitle(cells[labelColumnIndex]);
      if (!label) return;
      const rowLabel = total ? /^total\b/i.test(label) ? label : "Total" : label;
      for (let i = 0; i < cells.length; i++) {
        if (i === labelColumnIndex) continue;
        const colName = headers[i] ?? `Col${i}`;
        result[`${sectionPrefix}.${rowLabel}.${colName}`] = parseValue(
          getCellTitle(cells[i])
        );
      }
    });
    return result;
  }
  function scanSalesSummary() {
    const data = {};
    {
      const sectionData = extractKeyValueTable(
        document.querySelector('tbody[data-testid="revenue-summary-table-body"]'),
        "Revenue"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractKeyValueTable(
        document.querySelector('tbody[data-testid="net-sales-summary-table-body"]'),
        "Net Sales"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractKeyValueTable(
        document.querySelector('tbody[data-testid="tip-summary-table-body"]'),
        "Tips"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractKeyValueTable(
        document.querySelector('tbody[data-testid="cash-activity-table-body"]'),
        "Cash Activity"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractKeyValueTable(
        document.querySelector('tbody[data-testid="cash-summary-table-body"]'),
        "Cash Summary"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractKeyValueTable(
        document.querySelector('tbody[data-testid="unpaid-orders-summary-data-table-body"]'),
        "Unpaid Orders"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractKeyValueTable(
        document.querySelector('tbody[data-testid="void-summary-table-body"]'),
        "Void"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="payments-summary-table-header"]'),
        document.querySelector('tbody[data-testid="payments-summary-table-body"]'),
        "Payments"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="sales-categories-data-table-header"]'),
        document.querySelector('tbody[data-testid="sales-categories-data-table-body"]'),
        "Sales Category"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="tax-summary-data-table-header"]'),
        document.querySelector('tbody[data-testid="tax-summary-data-table-body"]'),
        "Tax"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="discount-data-table-header"]'),
        document.querySelector('tbody[data-testid="discount-data-table-body"]'),
        "Discount"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="service-charge-data-table-header"]'),
        document.querySelector('tbody[data-testid="service-charge-data-table-body"]'),
        "Service Charge"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="RevenueTable-data-table-header"]'),
        document.querySelector('tbody[data-testid="RevenueTable-data-table-body"]'),
        "Revenue Center"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="Services-data-table-header"]'),
        document.querySelector('tbody[data-testid="Services-data-table-body"]'),
        "Service Daypart"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="dining-options-data-table-header"]'),
        document.querySelector('tbody[data-testid="dining-options-data-table-body"]'),
        "Dining Option"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="service-mode-summary-data-table-header"]'),
        document.querySelector('tbody[data-testid="service-mode-summary-data-table-body"]'),
        "Service Mode"
      );
      Object.assign(data, sectionData);
    }
    {
      const sectionData = extractMultiColumnTable(
        document.querySelector('thead[data-testid="Deferred-data-table-header"]'),
        document.querySelector('tbody[data-testid="Deferred-data-table-body"]'),
        "Deferred"
      );
      Object.assign(data, sectionData);
    }
    return data;
  }
  if (globalThis.__toastScannerLoaded) {
    if (false) console.log("[Toast Scanner] Already loaded, skipping duplicate registration");
  } else {
    globalThis.__toastScannerLoaded = true;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message.type === "REQUEST_SCAN") {
        const url = window.location.href;
        const isSalesSummary = /\/restaurants\/admin\/reports\/sales\/sales-summary/.test(url);
        if (!isSalesSummary) {
          sendResponse({ data: null });
          return true;
        }
        waitForElement('tbody[data-testid="revenue-summary-table-body"]', 5e3).then((el) => {
          if (!el) {
            if (false) console.error("[Qyra Scanner] Timed out waiting for Sales Summary page to load");
            sendResponse({ data: null });
            return;
          }
          try {
            const scanData = scanSalesSummary();
            if (Object.keys(scanData).length === 0) {
              if (false) console.error("[Qyra Scanner] Page loaded but no data extracted \u2014 selectors may be outdated");
              sendResponse({ data: null });
              return;
            }
            sendResponse({ data: scanData });
          } catch (err) {
            if (false) console.error("[Qyra Scanner] Scan failed:", err);
            sendResponse({ data: null });
          }
        }).catch(() => {
          sendResponse({ data: null });
        });
        return true;
      }
      return false;
    });
  }
})();
