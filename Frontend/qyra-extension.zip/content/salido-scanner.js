"use strict";
(() => {
  // src/content/salido-scanner.ts
  function waitForElement(selector, timeoutMs = 8e3) {
    return new Promise((resolve) => {
      const existing = document.querySelector(selector);
      if (existing) return resolve(existing);
      const observer = new MutationObserver(() => {
        const el = document.querySelector(selector);
        if (el) {
          observer.disconnect();
          resolve(el);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, timeoutMs);
    });
  }
  function parseValue(raw) {
    const s = raw.trim();
    if (s === "\u2014" || s === "-" || s === "") return 0;
    if (/^\d{1,2}:\d{2}/.test(s)) return 0;
    if (/^\(.*\)$/.test(s)) {
      const inner = s.replace(/[()$,]/g, "");
      const num2 = parseFloat(inner);
      return isNaN(num2) ? 0 : -num2;
    }
    if (s.endsWith("%")) {
      const num2 = parseFloat(s.replace(/[^0-9.\-]/g, ""));
      return isNaN(num2) ? 0 : num2;
    }
    const cleaned = s.replace(/[$,]/g, "");
    if (cleaned.endsWith("-") && !cleaned.startsWith("-")) {
      const num2 = parseFloat(cleaned.slice(0, -1));
      return isNaN(num2) ? 0 : -num2;
    }
    const num = parseFloat(cleaned);
    return isNaN(num) ? 0 : num;
  }
  async function waitForDataLoaded(timeoutMs = 15e3) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const skeletons = document.querySelectorAll(".fake-table-entry");
      const noResults = document.querySelectorAll(".no-results-wrapper");
      const sections = document.querySelectorAll("div.reports-results");
      if (sections.length > 0 && skeletons.length === 0 && noResults.length === 0) {
        return true;
      }
      await new Promise((r) => setTimeout(r, 300));
    }
    return false;
  }
  function cellText(el, selector) {
    return el.querySelector(selector)?.textContent?.trim() ?? "";
  }
  function getColumnHeaders(headerTbody) {
    return Array.from(
      headerTbody.querySelectorAll("td.--grouped-header .table-cell-inner")
    ).map((el) => el.textContent?.trim() ?? "").filter((h) => h.length > 0);
  }
  function extractRegularSection(block, sectionName, headers) {
    const result = {};
    const rowGroups = block.querySelectorAll("tbody.result-row-group");
    rowGroups.forEach((group) => {
      group.querySelectorAll("tr.table-row").forEach((row) => {
        const label = cellText(row, "td.--value.--text .table-cell-inner");
        if (!label) return;
        const valueCells = Array.from(row.querySelectorAll("td.--value.--money .table-cell-inner"));
        if (headers.length > 0) {
          valueCells.forEach((cell, i) => {
            const colName = headers[i] ?? `Col${i + 1}`;
            result[`${sectionName}.${label}.${colName}`] = parseValue(cell.textContent ?? "");
          });
        } else {
          const val = valueCells[0]?.textContent ?? "";
          result[`${sectionName}.${label}`] = parseValue(val);
        }
      });
    });
    return result;
  }
  function extractGroupedSection(block, sectionName, headers) {
    const result = {};
    const rowGroups = block.querySelectorAll("tbody.result-row-group, tbody.result-row-group.--with-subheader");
    rowGroups.forEach((group) => {
      let currentGroup = "Other";
      group.querySelectorAll("tr.table-row").forEach((row) => {
        const subheaderEl = row.querySelector("td.--subheader .table-cell-inner");
        if (subheaderEl) {
          currentGroup = subheaderEl.textContent?.trim() ?? currentGroup;
          return;
        }
        const label = cellText(row, "td.--value.--text .table-cell-inner");
        if (!label) return;
        const valueCells = Array.from(row.querySelectorAll("td.--value.--money .table-cell-inner"));
        if (headers.length > 0) {
          valueCells.forEach((cell, i) => {
            const colName = headers[i] ?? `Col${i + 1}`;
            result[`${sectionName}.${currentGroup}.${label}.${colName}`] = parseValue(cell.textContent ?? "");
          });
        } else {
          const val = valueCells[0]?.textContent ?? "";
          result[`${sectionName}.${currentGroup}.${label}`] = parseValue(val);
        }
      });
    });
    return result;
  }
  async function scanAccountingSummary() {
    const data = {};
    const tableEl = await waitForElement("table.reports-table", 1e4);
    if (!tableEl) {
      console.warn("[SALIDO Scanner] No report table found \u2014 page may not be loaded");
      return data;
    }
    await waitForDataLoaded(15e3);
    const blocks = document.querySelectorAll("div.reports-results");
    blocks.forEach((block) => {
      const headerTbody = block.querySelector("tbody.table-header");
      if (!headerTbody) return;
      const sectionName = cellText(headerTbody, "td.summary-header .table-cell-inner") || "Unknown";
      const headers = getColumnHeaders(headerTbody);
      const table = block.querySelector("table.reports-table");
      const isGrouped = table?.classList.contains("grouped") ?? false;
      if (isGrouped) {
        Object.assign(data, extractGroupedSection(block, sectionName, headers));
      } else {
        Object.assign(data, extractRegularSection(block, sectionName, headers));
      }
    });
    return data;
  }
  if (globalThis.__salidoScannerLoaded) {
    if (false) console.log("[SALIDO Scanner] Already loaded, skipping duplicate registration");
  } else {
    globalThis.__salidoScannerLoaded = true;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type !== "REQUEST_SCAN") return false;
      if (false) console.log("[SALIDO Scanner] REQUEST_SCAN received");
      scanAccountingSummary().then((data) => {
        if (false) console.log(`[SALIDO Scanner] Extracted ${Object.keys(data).length} fields`);
        sendResponse({ data });
      }).catch((err) => {
        console.error("[SALIDO Scanner] Scan error:", err);
        sendResponse({ data: {} });
      });
      return true;
    });
  }
  if (false) console.log("[SALIDO Scanner] Content script loaded on", window.location.href);
})();
