"use strict";
(() => {
  // src/content/oracle-scanner.ts
  function parseValue(raw) {
    const s = raw.trim();
    if (s === "\u2014" || s === "-" || s === "") return 0;
    if (/^\d{1,2}:\d{2}/.test(s)) return 0;
    if (/^\(.*\)$/.test(s)) {
      const inner = s.replace(/[()$,]/g, "");
      const num2 = parseFloat(inner);
      return isNaN(num2) ? 0 : -num2;
    }
    if (s.endsWith("%")) {
      const num2 = parseFloat(s.replace(/[^0-9.\-]/g, ""));
      return isNaN(num2) ? 0 : num2;
    }
    const cleaned = s.replace(/[$,]/g, "");
    if (cleaned.endsWith("-") && !cleaned.startsWith("-")) {
      const num2 = parseFloat(cleaned.slice(0, -1));
      return isNaN(num2) ? 0 : -num2;
    }
    const num = parseFloat(cleaned);
    return isNaN(num) ? 0 : num;
  }
  async function waitForReportLoaded(timeoutMs = 25e3) {
    const deadline = Date.now() + timeoutMs;
    const tier1Deadline = Date.now() + 1e4;
    while (Date.now() < tier1Deadline) {
      const tiles = document.querySelectorAll("oj-rna-report-tile-cca");
      if (tiles.length > 0) {
        const allComplete = Array.from(tiles).every((t) => t.classList.contains("oj-complete"));
        if (allComplete) return true;
      }
      await new Promise((r) => setTimeout(r, 500));
    }
    while (Date.now() < deadline) {
      const grid = document.querySelector("table.oj-fbgbu-grid");
      if (grid) {
        const rows = grid.querySelectorAll("th.oj-fbgbu-grid-row-header");
        if (rows.length > 0) {
          const firstValue = rows[0].nextElementSibling;
          if (firstValue && firstValue.textContent?.trim()) return true;
        }
      }
      await new Promise((r) => setTimeout(r, 500));
    }
    return false;
  }
  var SKIP_SECTIONS = /* @__PURE__ */ new Set(["Payment Total by Tender Type", "Report Notes"]);
  function getSectionName(el) {
    let node = el;
    while (node) {
      if (node.tagName?.toLowerCase() === "oj-rna-report-tile-cca") {
        const label = node.getAttribute("aria-label");
        if (label) return label.trim();
      }
      node = node.parentElement;
    }
    let search = el.parentElement;
    while (search) {
      const h2 = search.querySelector("h2.oj-typography-subheading-sm");
      if (h2?.textContent) return h2.textContent.trim();
      search = search.parentElement;
    }
    return "Unknown";
  }
  function extractKPITiles() {
    const result = {};
    const labels = document.querySelectorAll("div.oj-fbgbu-panel-label");
    labels.forEach((labelEl) => {
      const label = labelEl.textContent?.trim();
      if (!label) return;
      const valueEl = labelEl.nextElementSibling?.matches(".oj-fbgbu-panel-value") ? labelEl.nextElementSibling : labelEl.parentElement?.querySelector(".oj-fbgbu-panel-value");
      if (!valueEl) return;
      result[`KPI.${label}`] = parseValue(valueEl.textContent ?? "");
    });
    return result;
  }
  function extractGridTable(tableEl, sectionName) {
    const result = {};
    const rows = tableEl.querySelectorAll("th.oj-fbgbu-grid-row-header");
    rows.forEach((th) => {
      const label = th.textContent?.trim();
      if (!label) return;
      const valueTd = th.nextElementSibling;
      if (!valueTd) return;
      const raw = valueTd.textContent?.trim() ?? "";
      result[`Summary.${label}`] = parseValue(raw);
    });
    return result;
  }
  function extractBreakdownTable(tableEl, sectionName) {
    const result = {};
    const headerTexts = Array.from(
      tableEl.querySelectorAll("thead div.oj-table-column-header-text")
    ).map((el) => el.textContent?.trim() ?? "");
    const rows = tableEl.querySelectorAll("tbody tr.oj-table-body-row");
    rows.forEach((row) => {
      const labelTd = row.querySelector("td.oj-helper-text-align-left");
      const labelSpan = labelTd?.querySelector("span") ?? labelTd;
      const label = (labelSpan?.textContent ?? labelTd?.textContent ?? "").trim();
      if (!label) return;
      const valueTds = Array.from(row.querySelectorAll("td.oj-helper-text-align-right"));
      valueTds.forEach((td, i) => {
        const colName = headerTexts[i + 1] ?? `Col${i + 1}`;
        const raw = td.textContent?.trim() ?? "";
        result[`${sectionName}.${label}.${colName}`] = parseValue(raw);
      });
    });
    return result;
  }
  async function scanDailyOperations() {
    const data = {};
    const loaded = await waitForReportLoaded(25e3);
    if (!loaded) {
      console.warn("[Oracle Scanner] Report did not fully load \u2014 attempting partial scan");
    }
    try {
      Object.assign(data, extractKPITiles());
    } catch (err) {
      console.warn("[Oracle Scanner] KPI tile extraction failed:", err);
    }
    const grids = document.querySelectorAll("table.oj-fbgbu-grid");
    grids.forEach((grid) => {
      const sectionName = getSectionName(grid);
      if (SKIP_SECTIONS.has(sectionName)) return;
      try {
        Object.assign(data, extractGridTable(grid, sectionName));
      } catch (err) {
        console.warn(`[Oracle Scanner] Grid extraction failed for "${sectionName}":`, err);
      }
    });
    const breakdownTables = document.querySelectorAll('table[id^="standard_table_"]');
    breakdownTables.forEach((table) => {
      const sectionName = getSectionName(table);
      if (SKIP_SECTIONS.has(sectionName)) return;
      try {
        Object.assign(data, extractBreakdownTable(table, sectionName));
      } catch (err) {
        console.warn(`[Oracle Scanner] Breakdown extraction failed for "${sectionName}":`, err);
      }
    });
    return data;
  }
  if (globalThis.__oracleScannerLoaded) {
    if (false) console.log("[Oracle Scanner] Already loaded, skipping duplicate registration");
  } else {
    globalThis.__oracleScannerLoaded = true;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type !== "REQUEST_SCAN") return false;
      if (false) console.log("[Oracle Scanner] REQUEST_SCAN received");
      (async () => {
        try {
          const data = await scanDailyOperations();
          if (false) console.log(`[Oracle Scanner] Extracted ${Object.keys(data).length} fields`);
          sendResponse({ data });
        } catch (err) {
          console.error("[Oracle Scanner] Scan error:", err);
          sendResponse({ data: {} });
        }
      })();
      return true;
    });
  }
  if (false) console.log("[Oracle Scanner] Content script loaded on", window.location.href);
})();
